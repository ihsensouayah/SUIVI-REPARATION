# Suivi Réparation AUTOP

Dashboard des véhicules **en cours de réparation** (tuile Odoo « Nombre de véhicule en Réparation »),
avec les heures validées par l'expert, la conversion **6 h = 1 jour** (arrondi au jour supérieur),
la date de fin prévue, l'avancement, les retards et les actions par dossier. Un écran **Affichage**
(grand format, pour une TV) montre dossier, véhicule, garage, statut et action.

```
Odoo ──(lecture seule, 2×/jour)──> GitHub Actions (agent/suivi_sync.py) ──> Firebase « suiviReparation/odoo »
                                                                                   │
            index.html (GitHub Pages, connexion obligatoire) <─────────────────────┘
            saisies manuelles (heures, dates, actions, commentaires) ──> Firebase « suiviReparation/saisies »
```

Le dépôt ne contient **aucune donnée** : tout est dans Firebase, protégé par mot de passe.

---

## Mise en place (une seule fois, environ 20 minutes)

### 1. Créer le dépôt GitHub
1. github.com → **New repository** → nom : `SuiviReparation` → **Public** → *Create repository*.
2. *uploading an existing file* → glisser **tout le contenu** de ce dossier (y compris le dossier `.github`)
   → *Commit changes*.
   > Si le dossier `.github` ne passe pas par glisser-déposer : *Add file → Create new file*,
   > nom `.github/workflows/suivi-sync.yml`, coller le contenu du fichier, *Commit*.

### 2. Créer le projet Firebase (gratuit, plan Spark)
1. console.firebase.google.com → **Ajouter un projet** → nom `autop-reparation` (Analytics inutile).
2. **Firestore Database** → *Créer une base de données* → mode **production** → région `eur3`.
3. Onglet **Règles** → remplacer tout par le contenu du fichier `firestore.rules` → *Publier*.
4. **Authentication** → *Commencer* → activer **E-mail/Mot de passe** →
   onglet *Users* → **Ajouter un utilisateur** pour chaque personne (e-mail + mot de passe).
5. ⚙️ **Paramètres du projet** → *Vos applications* → icône **</>** (Web) → nom `suivi` → copier
   l'objet `firebaseConfig`. Dans GitHub, ouvrir `config.js` → ✏️ → remplacer `null` par cet objet → *Commit*.
6. ⚙️ **Paramètres du projet** → **Comptes de service** → *Générer une nouvelle clé privée* (fichier JSON).
   ⚠️ Ne jamais envoyer ce fichier par mail ou chat : il va seulement dans le secret GitHub de l'étape 3.

### 3. Secrets GitHub de l'agent
Dépôt → *Settings → Secrets and variables → Actions → New repository secret* :

| Secret | Valeur |
|---|---|
| `ODOO_URL` | `https://autop-soft.autop.tn` |
| `ODOO_DB` | `AUTOP_PRODUCTION` |
| `ODOO_USER` | votre identifiant Odoo (le même que l'agent DashboardAchat) |
| `ODOO_API_KEY` | votre mot de passe Odoo (Odoo 13 n'a pas de clé API) |
| `FIREBASE_SERVICE_ACCOUNT` | **tout** le contenu du fichier JSON de l'étape 2.6 |

### 4. Publier la page
*Settings → Pages* → *Source* : **Deploy from a branch** → branche `main`, dossier `/ (root)` → *Save*.
L'adresse s'affiche après 1 à 2 minutes (`https://<votre-compte>.github.io/SuiviReparation/`).

### 5. Premier lancement de l'agent
Onglet **Actions** → « Synchro Odoo -> Suivi Réparation » → **Run workflow**.
Après environ 1 minute : coche verte ✅. Ouvrir la page, se connecter : les dossiers apparaissent.
Puis **Importer tableau de suivi** → choisir le fichier « Indicateur de Performance Suivie » :
la colonne « Rendez vous » devient la date de début de réparation.

---

## Fonctionnement au quotidien
- L'agent tourne **du lundi au samedi à 9h38 et 14h38** (heure de Tunis). Pour le lancer tout de suite :
  *Actions → Run workflow*.
- Il lit **la même liste que la tuile Odoo** « Nombre de véhicule en Réparation » : un véhicule qui entre
  en réparation apparaît tout seul, un véhicule sorti disparaît (ses saisies restent gardées).
- **Heures** : somme des lignes de la section « MAIN D'OEUVRE » du devis validé par l'expert, au taux horaire
  du garage. Les produits de peinture, ingrédients et forfaits sont exclus et signalés (« +autres »,
  « MO au forfait »).
- **Priorités** : une heure ou une date saisie à la main l'emporte toujours ; l'écart avec le devis s'affiche en rouge.
  Date de début : saisie manuelle → tableau de suivi importé → date « Début Réparation » d'Odoo.
- **Jours de travail** = heures ÷ 6, arrondi au jour supérieur (1,3 j → 2 j) ; modifiable avec le bouton « 6 h = 1 j ».
- L'agent ne fait **que lire** Odoo et n'écrit jamais dans vos saisies.

## En cas de problème
| Symptôme | Cause / solution |
|---|---|
| Croix rouge ❌ dans *Actions* « Authentification Odoo refusée » | Mot de passe Odoo changé : mettre à jour le secret `ODOO_API_KEY`. |
| ❌ « Variable d'environnement manquante » | Un secret de l'étape 3 manque ou est mal nommé. |
| Page : « Configuration manquante » | `config.js` contient encore `null` (étape 2.5). |
| Page : « Accès refusé » | Règles Firestore non publiées (étape 2.3) ou compte absent d'Authentication. |
| L'agent ne tourne plus | GitHub suspend les tâches planifiées d'un dépôt sans commit depuis 60 jours : *Actions* → réactiver. |

Test local de l'agent sans rien écrire : `python agent/suivi_sync.py --dry-run` (avec les variables `ODOO_*`).
